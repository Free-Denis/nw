"""
Audit-hypothesis pipeline — генерация проверяемых аудиторских гипотез.

Подход (bottom-up, без RAG, без эмбеддингов):
  Этап 1 (map). По КАЖДОМУ документу glm-5.1 строит «карточку» (суть, риск-
      сигналы, контрагенты, лица, суммы, ссылки, схема, риск-теги).
  Этап 2 (НЕЙРОННАЯ группировка). glm-5.1 сама группирует документы по смыслу
      (один/связанные контрагенты — напр. Ozon и Wildberries как маркетплейсы,
      одна схема, дробление решения). Учитывает смысл, а не только точные
      совпадения строк.
  Этап 3 (reduce). По каждой группе и сильным одиночкам — гипотеза.
  Этап 4. Ранжирование.

Инструкции — целиком в system; в user идёт только документ (до 20000 знаков).
Настраивается пользователем: тематика поиска, риск-теги, доп. инструкции,
пример гипотезы (есть дефолты).
"""

import json
import re
import threading
import traceback

from .features import resolve_columns, get_content, get, is_junk_text


# ── In-memory state ──────────────────────────────────────────────
HYPO_JOBS = {}
HYPO_LOCK = threading.Lock()

MAX_DOC_CHARS = 20000          # glm-5.1 спокойно держит большой контекст
GROUP_BATCH = 250              # сколько карточек отдаём в один вызов группировки

# ── Дефолтные настройки (пользователь может переопределить) ───────
DEFAULT_RISK_TAGS = [
    # аудит обеспечивающих процессов
    "закупки", "налоги", "связанные стороны", "авансирование",
    "обход лимитов или дробление", "спонсорство и благотворительность",
    "кадровые выплаты и льготы", "недвижимость и активы",
    "конфликт интересов", "гарантии и поручительства",
    "льготные условия контрагенту", "изменение ранее принятых решений",
    "маркетплейсы", "ИТ и подрядчики",
    # клиентские обращения и безопасность
    "мошенничество", "социальная инженерия", "несанкционированные списания",
    "автосписания за подписки", "коллекторы", "информационная безопасность",
    "компрометация аккаунта", "спорные транзакции", "качество обслуживания",
]

DEFAULT_INSTRUCTIONS = (
    "Обращай внимание на типовые красные флаги: 100% авансирование; выплаты из "
    "резервов в обход процедур; закупка у единственного поставщика; дробление "
    "сумм или решений ниже порогов согласования; частые изменения одного "
    "постановления; льготные условия отдельному контрагенту; одно лицо "
    "инициирует и принимает исполнение; связанные стороны и аффилированность."
)

DEFAULT_EXAMPLE = json.dumps({
    "risk": "Спонсорская выплата 35 млн ₽ со 100% авансом",
    "red_flag": "100% аванс и оплата из адресного резерва в обход типовой процедуры закупки",
    "testable_claim": "По авансу отсутствуют закрывающие акты и подтверждение факта мероприятия",
    "audit_procedure": "Сверить платёж с актами приёма-передачи и фактом мероприятия; проверить основание выплаты из резерва",
    "scope": "Все документы со 100% авансом за период выгрузки",
    "materiality": "высокая",
}, ensure_ascii=False, indent=2)

_HYPO_FIELDS = '{"risk":"","red_flag":"","testable_claim":"","audit_procedure":"","scope":"","materiality":"высокая/средняя/низкая"}'


# ══════════════════════════════════════════════════════════════════
# LLM helpers
# ══════════════════════════════════════════════════════════════════

def _extract_json(text):
    cleaned = re.sub(r"^```(?:json)?\s*", "", str(text).strip())
    cleaned = re.sub(r"\s*```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except (json.JSONDecodeError, ValueError):
        # спасение: вытащить первый JSON-объект из текста с лишними словами
        match = re.search(r"\{.*\}", cleaned, re.S)
        if match:
            return json.loads(match.group(0))
        raise


def _try_json(raw):
    try:
        return _extract_json(raw)
    except (json.JSONDecodeError, ValueError):
        return None


def _gc_json(gc, system_prompt, user_prompt, model=None, temperature=0):
    resp = gc.completions(
        [{"role": "system", "content": system_prompt},
         {"role": "user", "content": user_prompt}],
        temperature=temperature,
        model=model,
    )
    raw = resp["choices"][0]["message"]["content"].strip()
    try:
        return _extract_json(raw)
    except (json.JSONDecodeError, ValueError):
        return {"_error": "invalid_json", "_raw": raw}


def _norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


# ══════════════════════════════════════════════════════════════════
# Этап 1. Карточка документа (инструкции в system, документ в user)
# ══════════════════════════════════════════════════════════════════

def build_card_system(tags, instructions):
    tags_line = ", ".join(tags)
    extra = f"\n\nУказания аналитика: {instructions.strip()}" if instructions.strip() else ""
    return f"""Ты — внутренний аудитор. Разбери документ и извлеки ТОЛЬКО факты, ничего не выдумывай.
Если факта нет — оставь пустым/[].{extra}

Доступные риск-теги (выбери подходящие по смыслу; если ни один не подходит — предложи 1-2 своих коротких тега): {tags_line}

Ответь СТРОГО валидным JSON без markdown по схеме:
{{
  "summary": "подробный пересказ ВСЕЙ сути документа: что произошло, ключевые факты, суммы, стороны, чем это важно (3-6 предложений)",
  "risk_signals": ["конкретные красные флаги, если есть"],
  "counterparties": ["контрагенты/организации, если упомянуты"],
  "persons": ["ФИО ответственных лиц"],
  "amounts": [{{"value": "сумма как в тексте", "purpose": "на что"}}],
  "referenced_docs": ["реквизиты упомянутых/изменяемых документов"],
  "scheme": "короткая метка типа операции",
  "risk_tags": ["тег из списка"]
}}"""


# ══════════════════════════════════════════════════════════════════
# Этап 2. Нейронная группировка по смыслу
# ══════════════════════════════════════════════════════════════════

GROUP_SYSTEM = """Ты — аудитор-аналитик. Тебе дан нумерованный список карточек документов.
Объедини документы, между которыми есть аудиторски значимая связь:
- один контрагент ИЛИ связанные ПО СМЫСЛУ контрагенты (например, разные маркетплейсы
  Ozon и Wildberries; разные подрядчики одной схемы);
- одинаковая схема операции;
- дробление одного решения, повторяющийся паттерн.
Учитывай СМЫСЛ и предметную область, а не только точное совпадение строк.
Документ МОЖЕТ входить в несколько групп, если он относится к разным паттернам.
Документы без значимых связей не включай.

Ответь СТРОГО JSON без markdown:
{"groups": [{"doc_numbers": [1, 3, 7], "label": "короткое название группы", "reason": "что именно связывает документы"}]}"""


GROUP_MERGE_SYSTEM = """Ты — аудитор-аналитик. Дан список предварительных групп документов (каждая с описанием связи).
Некоторые группы могут описывать ОДИН И ТОТ ЖЕ паттерн, контрагента или схему, но были найдены отдельно
(например, в разных партиях документов). Объедини такие группы.
Ответь СТРОГО JSON без markdown: {"merges": [[1, 4], [2, 3, 5]]} — списки НОМЕРОВ групп, которые нужно слить.
Группы, которые объединять не нужно, можно не упоминать."""


def _compact_card(n, card):
    cp = ", ".join(card.get("counterparties") or []) or "—"
    tags = ", ".join(card.get("risk_tags") or []) or "—"
    scheme = str(card.get("scheme", "") or "—")
    return f"{n}. {str(card.get('summary', ''))[:200]} | контрагенты: {cp[:120]} | схема: {scheme[:60]} | теги: {tags}"


def _group_call_raw(gc, listing, model, strict=False):
    """Прямой вызов группировки — возвращает сырой текст ответа (для диагностики)."""
    user = ("Верни СТРОГО JSON вида {\"groups\":[...]}, без пояснений.\n\n" + listing) if strict else listing
    try:
        resp = gc.completions(
            [{"role": "system", "content": GROUP_SYSTEM}, {"role": "user", "content": user}],
            temperature=0, model=model,
        )
        return resp["choices"][0]["message"]["content"].strip()
    except Exception as exc:
        return f"(ошибка вызова модели: {exc})"


def _merge_cross_batch(gc, groups, model):
    """Иерархический проход: объединить группы из разных батчей по одному паттерну."""
    listing = "\n".join(f"{i + 1}. {'; '.join(g['links'])}" for i, g in enumerate(groups))
    try:
        resp = gc.completions(
            [{"role": "system", "content": GROUP_MERGE_SYSTEM}, {"role": "user", "content": listing}],
            temperature=0, model=model,
        )
        raw = resp["choices"][0]["message"]["content"].strip()
    except Exception:
        return groups, "объединение: пропущено (ошибка вызова)"
    res = _try_json(raw)
    merges = res.get("merges") if isinstance(res, dict) else None
    if not merges:
        return groups, "объединение: нечего сливать"

    parent = list(range(len(groups)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for cluster in merges:
        nums = []
        for n in cluster:
            try:
                pos = int(n) - 1
            except (TypeError, ValueError):
                continue
            if 0 <= pos < len(groups):
                nums.append(pos)
        for j in range(1, len(nums)):
            ra, rb = find(nums[0]), find(nums[j])
            if ra != rb:
                parent[rb] = ra

    buckets = {}
    for i in range(len(groups)):
        buckets.setdefault(find(i), []).append(i)
    merged = []
    for members in buckets.values():
        idxs = sorted({i for m in members for i in groups[m]["doc_indexes"]})
        links = [lnk for m in members for lnk in groups[m]["links"]]
        merged.append({"doc_indexes": idxs, "links": links})
    return merged, f"объединение групп между батчами: {len(groups)}→{len(merged)}"


def _neural_group(gc, cards, model):
    """cards: [{idx, card}]. Вернуть (группы, diag). diag содержит debug/raw/listing."""
    groups = []
    debug = []
    raws = []
    listings = []
    for start in range(0, len(cards), GROUP_BATCH):
        batch_no = start // GROUP_BATCH + 1
        chunk = cards[start:start + GROUP_BATCH]
        listing = "\n".join(_compact_card(i + 1, item["card"]) for i, item in enumerate(chunk))
        listings.append(listing)

        raw = _group_call_raw(gc, listing, model)
        res = _try_json(raw)
        if res is None and not raw.startswith("(ошибка"):
            # повтор со строгой инструкцией «только JSON»
            raw = _group_call_raw(gc, listing, model, strict=True)
            res = _try_json(raw)
        raws.append(f"[батч {batch_no}]\n{raw}")

        if res is None:
            debug.append(f"батч {batch_no}: невалидный/пустой ответ модели")
            continue
        raw_groups = res.get("groups") if isinstance(res, dict) else None
        if not raw_groups:
            debug.append(f"батч {batch_no}: нейросеть не нашла групп")
            continue
        before = len(groups)
        for g in raw_groups:
            idxs = []
            for num in g.get("doc_numbers") or []:
                try:
                    pos = int(num) - 1
                except (TypeError, ValueError):
                    continue
                if 0 <= pos < len(chunk):
                    idxs.append(chunk[pos]["idx"])
            idxs = sorted(set(idxs))
            if len(idxs) >= 2:
                reason = g.get("reason") or g.get("label") or "смысловая связь"
                groups.append({"doc_indexes": idxs, "links": [str(reason)]})
        debug.append(f"батч {batch_no}: групп {len(groups) - before}")

    # иерархический проход — только если было несколько батчей и есть что сливать
    num_batches = (len(cards) + GROUP_BATCH - 1) // GROUP_BATCH
    if num_batches > 1 and len(groups) >= 2:
        groups, merge_note = _merge_cross_batch(gc, groups, model)
        debug.append(merge_note)

    groups.sort(key=lambda x: len(x["doc_indexes"]), reverse=True)
    diag = {
        "debug": f"карточек: {len(cards)}; групп: {len(groups)}; " + "; ".join(debug),
        "raw": "\n\n".join(raws)[:4000],
        "listing": "\n".join(listings)[:6000],
    }
    return groups, diag


# ══════════════════════════════════════════════════════════════════
# Этап 3. Гипотезы (инструкции/пример/тема — в system)
# ══════════════════════════════════════════════════════════════════

def _hypo_system(base, instructions, example, theme):
    parts = [base]
    if instructions.strip():
        parts.append("Указания аналитика:\n" + instructions.strip())
    if theme.strip():
        parts.append(
            f"ФОКУС: рассматривай только тему «{theme.strip()}». "
            'Если документ/группа не относится к теме — верни {"no_hypothesis": true}.'
        )
    if example.strip():
        parts.append("Пример формата гипотезы (это образец структуры, а не единственный вид риска):\n" + example.strip())
    parts.append("Отвечай СТРОГО валидным JSON без markdown.")
    return "\n\n".join(parts)


_GROUP_BASE = (
    "Ты — старший внутренний аудитор Сбера. Тебе дана ГРУППА связанных документов. "
    "Найди аудиторский паттерн, видимый на группе, и сформулируй ОДНУ проверяемую "
    f"гипотезу по структуре {_HYPO_FIELDS}. Если общего паттерна нет — верни "
    '{"no_hypothesis": true}.'
)

_SINGLE_BASE = (
    "Ты — старший внутренний аудитор Сбера. По карточке одного документа сформулируй "
    f"ОДНУ проверяемую гипотезу по структуре {_HYPO_FIELDS}, если есть реальное основание. "
    'Если оснований нет — верни {"no_hypothesis": true}.'
)


def build_group_hypothesis_user(group_cards, links):
    """Подаём карточки: в summary — полный пересказ сути, плюс факты/сигналы/суммы."""
    docs_block = "\n\n".join(
        f"Документ {i + 1}: {json.dumps(c, ensure_ascii=False)}"
        for i, c in enumerate(group_cards)
    )
    return (
        f"Что связывает документы: {'; '.join(links)}\n\n"
        f"Карточки документов группы (в summary — полный пересказ сути):\n{docs_block}"
    )


def build_single_hypothesis_user(card):
    return f"Карточка документа (в summary — полный пересказ сути): {json.dumps(card, ensure_ascii=False)}"


def _source_entry(idx, doc_meta, card_by_idx):
    """Источник с указанием, ЧТО именно подозрительно (риск-сигналы), а не начало."""
    entry = dict(doc_meta[idx])
    card = card_by_idx.get(idx, {})
    signals = card.get("risk_signals") or []
    suspicious = "; ".join(str(s) for s in signals) if signals else str(card.get("summary", ""))
    entry["suspicious"] = suspicious[:300]
    return entry


# ══════════════════════════════════════════════════════════════════
# Этап 4. Ранжирование
# ══════════════════════════════════════════════════════════════════

_MATERIALITY_WEIGHT = {"высокая": 3, "средняя": 2, "низкая": 1}


DEDUP_SYSTEM = """Ты — аудитор. Дан нумерованный список гипотез (риск + проверяемое утверждение).
Найди гипотезы, которые описывают ОДИН И ТОТ ЖЕ риск (совпадает суть). НЕ объединяй разные риски,
даже если у них общая тема — это разные гипотезы.
Ответь СТРОГО JSON без markdown: {"duplicates": [[1, 4], [2, 5, 6]]} — списки номеров гипотез-дублей.
Если дублей нет — {"duplicates": []}."""


def _dedup_hypotheses(gc, hypotheses, model):
    """Схлопнуть совпадающие по сути гипотезы: объединить источники, оставить лучшую."""
    if len(hypotheses) < 2:
        return hypotheses, "дедуп: не требуется"
    listing = "\n".join(
        f"{i + 1}. риск: {h.get('risk', '')} | проверяем: {h.get('testable_claim', '')}"
        for i, h in enumerate(hypotheses)
    )
    try:
        resp = gc.completions(
            [{"role": "system", "content": DEDUP_SYSTEM}, {"role": "user", "content": listing}],
            temperature=0, model=model,
        )
        raw = resp["choices"][0]["message"]["content"].strip()
    except Exception:
        return hypotheses, "дедуп: пропущен (ошибка вызова)"
    res = _try_json(raw)
    clusters = res.get("duplicates") if isinstance(res, dict) else None
    if not clusters:
        return hypotheses, "дедуп: дублей нет"

    parent = list(range(len(hypotheses)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for cluster in clusters:
        nums = []
        for n in cluster:
            try:
                pos = int(n) - 1
            except (TypeError, ValueError):
                continue
            if 0 <= pos < len(hypotheses):
                nums.append(pos)
        for j in range(1, len(nums)):
            ra, rb = find(nums[0]), find(nums[j])
            if ra != rb:
                parent[rb] = ra

    buckets = {}
    for i in range(len(hypotheses)):
        buckets.setdefault(find(i), []).append(i)

    merged = []
    removed = 0
    for members in buckets.values():
        if len(members) == 1:
            merged.append(hypotheses[members[0]])
            continue
        rep = max(members, key=lambda m: (
            _MATERIALITY_WEIGHT.get(_norm(hypotheses[m].get("materiality")), 1),
            len(hypotheses[m].get("sources", [])),
        ))
        h = dict(hypotheses[rep])
        seen, src = set(), []
        for m in members:
            for s in hypotheses[m].get("sources", []):
                key = s.get("row")
                if key not in seen:
                    seen.add(key)
                    src.append(s)
        h["sources"] = src
        h["merged_from"] = len(members)
        if any(hypotheses[m].get("kind") == "cross_document" for m in members):
            h["kind"] = "cross_document"
        merged.append(h)
        removed += len(members) - 1
    return merged, f"дедуп: {len(hypotheses)}→{len(merged)} (объединено {removed})"


def rank_hypotheses(hypotheses):
    def score(h):
        return (
            1 if h.get("kind") == "cross_document" else 0,
            _MATERIALITY_WEIGHT.get(_norm(h.get("materiality")), 1),
            len(h.get("sources", [])),
        )
    return sorted(hypotheses, key=score, reverse=True)


# ══════════════════════════════════════════════════════════════════
# Воркер
# ══════════════════════════════════════════════════════════════════

def _new_hypo_job():
    return {
        "status": "running",
        "progress": {"current": 0, "total": 0, "stage": "Запуск..."},
        "groups": [],
        "group_debug": "",
        "group_raw": "",
        "cards_preview": "",
        "hypotheses": [],
        "error": None,
        "cancelled": False,
    }


def _update_progress(job_id, current, total, stage):
    with HYPO_LOCK:
        job = HYPO_JOBS.get(job_id)
        if job:
            job["progress"] = {"current": current, "total": total, "stage": stage}


def _cancelled(job_id):
    with HYPO_LOCK:
        return HYPO_JOBS.get(job_id, {}).get("cancelled", False)


def _row_content(row, colmap, content_column):
    if content_column and content_column in row:
        val = row.get(content_column)
        text = "" if val is None else str(val).strip()
        if text and text.lower() != "nan":
            return text
    return get_content(row, colmap)


def run_hypothesis_job(job_id, rows, colmap=None, model=None, content_column=None,
                       theme="", instructions="", tags=None, example=""):
    """Разобрать все документы, сгруппировать нейросетью, сгенерировать гипотезы."""
    try:
        from .gigachat import GigaChatClient
        gc = GigaChatClient.get_instance()
        if colmap is None and rows:
            colmap = resolve_columns(rows[0].keys())

        tags = tags or DEFAULT_RISK_TAGS
        instructions = instructions or DEFAULT_INSTRUCTIONS
        example = example or DEFAULT_EXAMPLE
        theme = theme or ""
        card_system = build_card_system(tags, instructions)
        group_hypo_system = _hypo_system(_GROUP_BASE, instructions, example, theme)
        single_hypo_system = _hypo_system(_SINGLE_BASE, instructions, example, theme)

        doc_meta = [
            {
                "row": idx + 1,
                "subject": str(get(row, colmap, "subject", "")) or _row_content(row, colmap, content_column)[:120],
                "link": str(get(row, colmap, "link", "")),
            }
            for idx, row in enumerate(rows)
        ]

        # ── Этап 1: карточки ──
        total = len(rows)
        cards = []
        skipped = 0
        for idx, row in enumerate(rows):
            if _cancelled(job_id):
                return
            _update_progress(job_id, idx + 1, total, f"Разбор документа {idx + 1} из {total}")
            content = _row_content(row, colmap, content_column)
            if is_junk_text(content):
                skipped += 1
                continue
            card = _gc_json(gc, card_system, content[:MAX_DOC_CHARS], model=model)
            if "_error" in card:
                continue
            cards.append({"idx": idx, "card": card})

        # ── Этап 2: нейронная группировка ──
        _update_progress(job_id, total, total, "Группировка документов по смыслу (нейросеть)...")
        groups, group_diag = _neural_group(gc, cards, model)
        grouped_idx = {i for g in groups for i in g["doc_indexes"]}
        card_by_idx = {item["idx"]: item["card"] for item in cards}

        with HYPO_LOCK:
            if job_id in HYPO_JOBS:
                HYPO_JOBS[job_id]["group_debug"] = group_diag["debug"]
                HYPO_JOBS[job_id]["group_raw"] = group_diag["raw"]
                HYPO_JOBS[job_id]["cards_preview"] = group_diag["listing"]
                HYPO_JOBS[job_id]["groups"] = [
                    {
                        "doc_indexes": g["doc_indexes"],
                        "links": g["links"],
                        "sources": [_source_entry(i, doc_meta, card_by_idx) for i in g["doc_indexes"]],
                    }
                    for g in groups
                ]

        hypotheses = []

        # ── Этап 3a: гипотезы по группам ──
        for n, g in enumerate(groups, 1):
            if _cancelled(job_id):
                return
            _update_progress(job_id, n, len(groups), f"Гипотеза по группе {n} из {len(groups)}")
            group_cards = [card_by_idx[i] for i in g["doc_indexes"][:12]]
            hypo = _gc_json(gc, group_hypo_system,
                            build_group_hypothesis_user(group_cards, g["links"]), model=model)
            if "_error" in hypo or hypo.get("no_hypothesis"):
                continue
            hypo.update({
                "kind": "cross_document",
                "doc_indexes": g["doc_indexes"],
                "links": g["links"],
                "sources": [_source_entry(i, doc_meta, card_by_idx) for i in g["doc_indexes"]],
            })
            hypotheses.append(hypo)

        # ── Этап 3b: сильные одиночки ──
        singles = [
            item for item in cards
            if item["idx"] not in grouped_idx and item["card"].get("risk_signals")
        ]
        for n, item in enumerate(singles, 1):
            if _cancelled(job_id):
                return
            _update_progress(job_id, n, len(singles), f"Гипотеза по одиночному документу {n} из {len(singles)}")
            hypo = _gc_json(gc, single_hypo_system,
                            build_single_hypothesis_user(item["card"]), model=model)
            if "_error" in hypo or hypo.get("no_hypothesis"):
                continue
            hypo.update({
                "kind": "single_document",
                "doc_index": item["idx"],
                "sources": [_source_entry(item["idx"], doc_meta, card_by_idx)],
            })
            hypotheses.append(hypo)

        # ── Финальная сверка: дедуп совпадающих гипотез ──
        dedup_note = ""
        if len(hypotheses) >= 2 and not _cancelled(job_id):
            _update_progress(job_id, 1, 1, "Сверка гипотез (объединение дублей)...")
            hypotheses, dedup_note = _dedup_hypotheses(gc, hypotheses, model)

        ranked = rank_hypotheses(hypotheses)
        with HYPO_LOCK:
            job = HYPO_JOBS.get(job_id)
            if job:
                job["hypotheses"] = ranked
                job["status"] = "done"
                job["progress"]["stage"] = (
                    f"Готово: {len(ranked)} гипотез из {len(cards)} документов"
                    + (f" (пропущено мусора: {skipped})" if skipped else "")
                    + (f"; {dedup_note}" if dedup_note else "")
                )
    except Exception as exc:
        traceback.print_exc()
        with HYPO_LOCK:
            job = HYPO_JOBS.get(job_id)
            if job:
                job["status"] = "error"
                job["error"] = str(exc)
